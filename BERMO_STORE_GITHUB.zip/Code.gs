const PRODUCTS = 'المنتجات';
const ORDERS = 'الطلبات';
const DEFAULT_USERNAME = 'admin';
const DEFAULT_PASSWORD = '1991';
const SESSION_HOURS = 6;
const FALLBACK_SPREADSHEET_ID = '1cmJskbTSRxuTppZFiRc79EbWLmU_WMgUkzXgddcPbDg';

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function ok_(data) { return json_({ ok: true, data: data }); }
function err_(message) { return json_({ ok: false, error: String(message || 'حدث خطأ') }); }

function ss_() {
  const id = PropertiesService.getScriptProperties().getProperty('STORE_SPREADSHEET_ID') ||
             (SpreadsheetApp.getActiveSpreadsheet() && SpreadsheetApp.getActiveSpreadsheet().getId()) ||
             FALLBACK_SPREADSHEET_ID;
  return SpreadsheetApp.openById(id);
}

function getPassword_() {
  const props = PropertiesService.getScriptProperties();
  let p = props.getProperty('STORE_ADMIN_PASSWORD');
  if (!p) { p = DEFAULT_PASSWORD; props.setProperty('STORE_ADMIN_PASSWORD', p); }
  return p;
}

function setupStore() {
  const s = ss_();
  let products = s.getSheetByName(PRODUCTS);
  if (!products) products = s.insertSheet(PRODUCTS);
  let orders = s.getSheetByName(ORDERS);
  if (!orders) orders = s.insertSheet(ORDERS);

  const productHeaders = ['id','title','price','currency','days','duration','image','description','payment','delivery','instructions','active'];
  if (products.getLastRow() === 0) products.getRange(1,1,1,productHeaders.length).setValues([productHeaders]);
  else if (products.getRange(1,1,1,productHeaders.length).getValues()[0].join('') === '') products.getRange(1,1,1,productHeaders.length).setValues([productHeaders]);

  const orderHeaders = ['id','createdAt','name','phone','email','product','duration','price','currency','payment','delivery','notes','status'];
  if (orders.getLastRow() === 0) orders.getRange(1,1,1,orderHeaders.length).setValues([orderHeaders]);
  ensureDefaults();
  return true;
}

function ensureDefaults() {
  const sh = ss_().getSheetByName(PRODUCTS) || ss_().insertSheet(PRODUCTS);
  const headers = ['id','title','price','currency','days','duration','image','description','payment','delivery','instructions','active'];
  if (sh.getLastRow() === 0) sh.getRange(1,1,1,headers.length).setValues([headers]);
  const values = sh.getDataRange().getValues();
  const ids = {};
  for (let i=1;i<values.length;i++) if (values[i][0] !== '') ids[String(values[i][0])] = true;
  const defaults = defaultProducts_().filter(p => !ids[p.id]);
  if (defaults.length) sh.getRange(sh.getLastRow()+1,1,defaults.length,headers.length).setValues(defaults.map(productRow_));
  repairProducts_();
}

function defaultProducts_() {
  return [
    {id:'gamma-ai',title:'Gamma AI',price:7,currency:'$',days:30,duration:'شهر',image:'local:gamma-ai',description:'',payment:'الدفع أولًا',delivery:'WhatsApp',instructions:'',active:true},
    {id:'gemini-pro',title:'Gemini Pro',price:8,currency:'$',days:30,duration:'شهر',image:'local:gemini-pro',description:'',payment:'الدفع أولًا',delivery:'WhatsApp',instructions:'',active:true},
    {id:'chatgpt-go',title:'ChatGPT Go',price:5,currency:'$',days:30,duration:'شهر',image:'local:chatgpt-go',description:'',payment:'الدفع أولًا',delivery:'WhatsApp',instructions:'',active:true},
    {id:'chatgpt-plus',title:'ChatGPT Plus',price:10,currency:'$',days:30,duration:'شهر',image:'local:chatgpt-plus',description:'',payment:'الدفع أولًا',delivery:'WhatsApp',instructions:'',active:true},
    {id:'manus-ai',title:'Manus AI',price:10,currency:'$',days:30,duration:'شهر',image:'local:manus-ai',description:'',payment:'الدفع أولًا',delivery:'WhatsApp',instructions:'',active:true},
    {id:'capcut-pro',title:'CapCut Pro',price:6,currency:'$',days:30,duration:'شهر',image:'local:capcut-pro',description:'',payment:'الدفع أولًا',delivery:'WhatsApp',instructions:'',active:true},
    {id:'claude-ai',title:'Claude AI',price:8,currency:'$',days:30,duration:'شهر',image:'local:claude-ai',description:'',payment:'الدفع أولًا',delivery:'WhatsApp',instructions:'',active:true},
    {id:'canva-pro',title:'Canva Pro',price:6,currency:'$',days:30,duration:'شهر',image:'local:canva-pro',description:'',payment:'الدفع أولًا',delivery:'WhatsApp',instructions:'',active:true}
  ];
}

function productRow_(p) {
  return [p.id,p.title,Number(p.price)||0,p.currency||'$',Number(p.days)||30,p.duration||'',p.image||'',p.description||'',p.payment||'',p.delivery||'',p.instructions||'',p.active!==false];
}

function repairProducts_() {
  const sh = ss_().getSheetByName(PRODUCTS); if (!sh || sh.getLastRow() < 2) return;
  const data = sh.getDataRange().getValues();
  const seen = {}, out = [data[0]];
  for (let i=1;i<data.length;i++) {
    const r=data[i], id=String(r[0]||'').trim();
    if (!id || seen[id]) continue;
    seen[id]=true; out.push(r);
  }
  if (out.length !== data.length) { sh.clearContents(); sh.getRange(1,1,out.length,out[0].length).setValues(out); }
}

function rowsToProducts_(rows) {
  return rows.slice(1).filter(r=>r[0]!=='' && r[11]!==false && String(r[11]).toLowerCase()!=='false').map(r=>({
    id:r[0],title:r[1],price:Number(r[2])||0,currency:r[3]||'$',days:Number(r[4])||30,duration:r[5]||'',image:r[6]||'',description:r[7]||'',payment:r[8]||'',delivery:r[9]||'',instructions:r[10]||'',active:r[11]!==false && String(r[11]).toLowerCase()!=='false'
  }));
}

function getAllProducts_() {
  setupStore();
  const sh=ss_().getSheetByName(PRODUCTS);
  return rowsToProducts_(sh.getDataRange().getValues());
}

function getProducts(all, token) {
  if (all && !validSession_(token)) throw new Error('غير مصرح');
  setupStore();
  const sh=ss_().getSheetByName(PRODUCTS), data=sh.getDataRange().getValues();
  if (all) return data.slice(1).filter(r=>r[0]!=='' ).map(r=>({id:r[0],title:r[1],price:Number(r[2])||0,currency:r[3]||'$',days:Number(r[4])||30,duration:r[5]||'',image:r[6]||'',description:r[7]||'',payment:r[8]||'',delivery:r[9]||'',instructions:r[10]||'',active:r[11]!==false && String(r[11]).toLowerCase()!=='false'}));
  return rowsToProducts_(data);
}

function saveProduct(p, token) {
  if (!validSession_(token)) throw new Error('انتهت الجلسة');
  if (!p || !String(p.title||'').trim()) throw new Error('اكتب اسم البرنامج');
  setupStore();
  const sh=ss_().getSheetByName(PRODUCTS), data=sh.getDataRange().getValues();
  const id=String(p.id||Date.now());
  const row=productRow_({id:id,title:String(p.title).trim(),price:Number(p.price)||0,currency:p.currency||'$',days:Number(p.days)||30,duration:p.duration||'',image:p.image||'',description:p.description||'',payment:p.payment||'',delivery:p.delivery||'',instructions:p.instructions||'',active:p.active!==false});
  let found=-1; for(let i=1;i<data.length;i++) if(String(data[i][0])===id){found=i+1;break;}
  if(found>0) sh.getRange(found,1,1,row.length).setValues([row]); else sh.getRange(sh.getLastRow()+1,1,1,row.length).setValues([row]);
  return true;
}

function deleteProduct(id, token) {
  if (!validSession_(token)) throw new Error('انتهت الجلسة');
  const sh=ss_().getSheetByName(PRODUCTS); if(!sh) return true;
  const data=sh.getDataRange().getValues();
  for(let i=data.length-1;i>=1;i--) if(String(data[i][0])===String(id)){sh.deleteRow(i+1);break;}
  return true;
}

function createOrder(d) {
  if (!d || !String(d.name||'').trim() || !String(d.phone||'').trim()) throw new Error('الاسم ورقم WhatsApp مطلوبان');
  setupStore();
  const sh=ss_().getSheetByName(ORDERS);
  const id=Date.now().toString();
  sh.appendRow([id,new Date(),String(d.name).trim(),String(d.phone).trim(),String(d.email||'').trim(),d.product||'',d.duration||'',d.price||'',d.currency||'',d.payment||'',d.delivery||'',d.notes||'','جديد']);
  return {id:id};
}

function adminLogin(username,password) {
  if (String(username)!==DEFAULT_USERNAME || String(password)!==getPassword_()) throw new Error('اسم المستخدم أو كلمة المرور غير صحيحة');
  const token=Utilities.getUuid(); CacheService.getScriptCache().put('BERMO_SESSION_'+token, '1', SESSION_HOURS*3600);
  return {token:token};
}

function validSession_(token) { return !!token && CacheService.getScriptCache().get('BERMO_SESSION_'+token)==='1'; }
function adminLogout(token) { if(token) CacheService.getScriptCache().remove('BERMO_SESSION_'+token); return true; }
function changeAdminPassword(token,password) { if(!validSession_(token)) throw new Error('انتهت الجلسة'); if(String(password||'').length<6) throw new Error('كلمة المرور يجب أن تكون 6 أحرف على الأقل'); PropertiesService.getScriptProperties().setProperty('STORE_ADMIN_PASSWORD',String(password)); return true; }

function doGet(e) {
  try {
    const p=e&&e.parameter||{};
    if(p.action==='getProducts') return ok_(getProducts(p.all==='1'||p.all==='true',p.token||''));
    return json_({ok:true,service:'BERMO STORE API',message:'API يعمل',actions:['getProducts','createOrder','adminLogin','saveProduct','deleteProduct','adminLogout','changeAdminPassword']});
  } catch(err) { return err_(err.message); }
}

function doPost(e) {
  try {
    const p=e&&e.parameter||{};
    let body={};
    if(p.payload) { try { body=JSON.parse(p.payload); } catch(_) {} }
    const action=p.action||body.action;
    const d=body.data||body;
    if(action==='createOrder') return ok_(createOrder(d));
    if(action==='adminLogin') return ok_(adminLogin(d.username,d.password));
    if(action==='saveProduct') return ok_(saveProduct(d.product,d.token));
    if(action==='deleteProduct') return ok_(deleteProduct(d.id,d.token));
    if(action==='adminLogout') return ok_(adminLogout(d.token));
    if(action==='changeAdminPassword') return ok_(changeAdminPassword(d.token,d.password));
    if(action==='getProducts') return ok_(getProducts(!!d.all,d.token||''));
    return err_('Action غير معروف');
  } catch(err) { return err_(err.message); }
}
